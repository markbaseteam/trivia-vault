---
tags:
  - GraphExclude
aliases: 
title: Home Page
---
# Home Page
I am building this knowledge vault to help myself learn different forms of trivia and factual knowledge. It is broken into the following categories
1. [[Geography]]
2. [[History]]
3. [[TODO]]...

I am populating each category as I learn new things. As a starting point, I am learning more about [[Geography]]
